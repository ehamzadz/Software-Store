Instructions:

1. Execute Activator.exe

Known issues:

1. If a security prompt appears on some operating systems, just confirm it directly.
=================