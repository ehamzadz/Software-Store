# RAD-Studio-11-Patch
RAD Studio 11 Patch - Alexandria

Execute 'Activator.exe'

Press button 'Active'.

RAD Studio 11 Alexandria - Has now been activated through keygening and patching.
